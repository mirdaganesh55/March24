package com.java.hib;

public interface StudentDAO {
	
}
