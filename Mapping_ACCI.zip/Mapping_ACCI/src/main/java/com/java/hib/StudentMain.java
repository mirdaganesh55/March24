package com.java.hib;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class StudentMain {

	static SessionFactory sf;
	static Session session;

	public static void main(String[] args) {

		sf = SessionHelper.getConnection();
		session = sf.openSession();

		String cous[] = {"JAVA","DOTNET","PYTHON","JSP","SERVLET"};

		List<String> ems = new ArrayList<String>();
		ems.add("ganeshmirda@gmail.com");
		ems.add("ranjuhandsa12@gmail.com");
		ems.add("rahulraman1234@gmail.com");

		List<Integer> mark = new ArrayList<Integer>();
		mark.add(89);
		mark.add(76);
		mark.add(99);

		Set<Long> phns = new HashSet<Long>();
		phns.add((long) 1234567);
		phns.add((long) 8765433);
		phns.add((long) 2345671);

		Map<String, Long> refs = new HashMap<String,Long>();
		refs.put("aaa", (long) 1234567);
		refs.put("bbb", (long) 8765433);
		refs.put("ccc", (long) 2345671);

		Student student = new Student("Santosh","10-10-2024","B.TECH",cous,ems,mark,phns,refs);
		session.save(student);
		System.out.println(student);
		sf.close();
		session.close();
	}
}